/**
 * 
 */
package prj5;

import student.TestCase;

/**
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/11/2018
 *
 */
public class MusicCollectionTest extends TestCase {

    private MusicCollection mc;


    /**
     * Set up method
     */
    public void setUp() {
        mc = new MusicCollection("Call Me Maybe", "Carly Rae Jepsen", "2010",
            "Pop");
    }


    /**
     * tests that get title returns correct title
     */
    public void testGetTitle() {
        assertEquals("Call Me Maybe", mc.getTitle());
    }


    /**
     * tests that get artist returns correct artist of song
     */
    public void testGetArtist() {
        assertEquals("Carly Rae Jepsen", mc.getArtist());
    }


    /**
     * tests that get year returns the correct year song
     * was released
     */
    public void testGetYear() {
        assertEquals("2010", mc.getYear());

    }


    /**
     * tests that get genre returns the correct genre of
     * the song
     */
    public void getGenre() {
        assertEquals("Pop", mc.getGenre());
    }

    /**
     * Tests adding "heard" and likes to a song
     * for any of the four majors
     *
     */
    public void testMajor() {
        assertEquals(0, mc.getMajorData(0));
        assertEquals(0, mc.getMajorLikes(0));

        mc.addMajorData(0);
        mc.addMajorData(0);

        mc.addMajorLikes(0);

        assertEquals(2, mc.getMajorData(0));
        assertEquals(1, mc.getMajorLikes(0));
    }

    /**
     * Tests adding "heard" and likes to a song
     * for any of the four hobbies
     *
     */
    public void testHobby() {
        assertEquals(0, mc.getHobbyData(0));
        assertEquals(0, mc.getHobbyLikes(0));

        mc.addHobbyData(0);
        mc.addHobbyData(0);

        mc.addHobbyLikes(0);

        assertEquals(2, mc.getHobbyData(0));
        assertEquals(1, mc.getHobbyLikes(0));
        
        mc.setHobbyData(0, 4);
        assertEquals(50, mc.getHobbyData(0));
        
        mc.setHobbyLikes(0, 2);
        assertEquals(50, mc.getHobbyData(0));
    }
    
    /**
     * Tests adding "heard" and likes to a song
     * for any of the four regions
     *
     */
    public void testRegion() {
        assertEquals(0, mc.getRegionData(0));
        assertEquals(0, mc.getRegionLikes(0));

        mc.addRegionData(0);
        mc.addRegionData(0);

        mc.addRegionLikes(0);

        assertEquals(2, mc.getRegionData(0));
        assertEquals(1, mc.getRegionLikes(0));
    }



    /**
     * test the to string method
     */
    public void testToString() {

        assertEquals("Title: Call Me Maybe" + "\n" + "Artist: Carly Rae Jepsen"
            + "\n" + "Year: 2010" + "\n" + "Genre: Pop", mc.toString());
    }
    
}

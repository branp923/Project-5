/**
 * 
 */
package prj5;

import student.TestCase;

/**
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/14/2018
 *
 */
public class SorterTest extends TestCase {
    private Sorter s1;
    private MusicCollection mc1;
    private MusicCollection mc2;
    private MusicCollection mc3;


    /**
     * set up method
     */
    public void setUp() {
        s1 = new Sorter();
        mc1 = new MusicCollection("A", "Matt", "2010", "Pop");
        mc2 = new MusicCollection("B", "Brandon", "2000", "Rock");
        mc3 = new MusicCollection("C", "Cole", "2007", "Country");
    }


    /**
     * tests that sort by genre correctly sorts
     * the songs
     */
    public void testSortByGenre() {
        // Correct order
        s1.add(mc3);
        s1.add(mc1);
        s1.add(mc2);

        Sorter sortGenre = new Sorter();
        sortGenre.add(mc1);
        sortGenre.add(mc2);
        sortGenre.add(mc3);

        sortGenre.sortByGenre();

        assertEquals(s1.get(0), sortGenre.get(0));
        assertEquals(s1.get(1), sortGenre.get(1));
        assertEquals(s1.get(2), sortGenre.get(2));
    }


    /**
     * tests that sort by title correctly sorts
     * the songs
     */
    public void testSortByTitle() {
        //Correct order
        s1.add(mc1);
        s1.add(mc2);
        s1.add(mc3);

        Sorter sortTitle = new Sorter();
        sortTitle.add(mc3);
        sortTitle.add(mc1);
        sortTitle.add(mc2);

        sortTitle.sortByTitle();

        assertEquals(s1.get(0), sortTitle.get(0));
        assertEquals(s1.get(1), sortTitle.get(1));
        assertEquals(s1.get(2), sortTitle.get(2));
        
        assertEquals(s1.toString(), sortTitle.toString());
    }
    
    /**
     * tests sort by artist
     */
    public void testSortByArtist()
    {
      //Correct order
        s1.add(mc2);
        s1.add(mc3);
        s1.add(mc1);

        Sorter sortArtist = new Sorter();
        sortArtist.add(mc1);
        sortArtist.add(mc2);
        sortArtist.add(mc3);

        sortArtist.sortByArtist();

        assertEquals(s1.get(0), sortArtist.get(0));
        assertEquals(s1.get(1), sortArtist.get(1));
        assertEquals(s1.get(2), sortArtist.get(2));
        
        assertEquals(s1.toString(), sortArtist.toString());
    }
    
    /**
     * test sort by year
     */
    public void testSortByYear()
    {
      //Correct order
        s1.add(mc2);
        s1.add(mc3);
        s1.add(mc1);

        Sorter sortYear = new Sorter();
        sortYear.add(mc1);
        sortYear.add(mc2);
        sortYear.add(mc3);

        sortYear.sortByYear();

        assertEquals(s1.get(0), sortYear.get(0));
        assertEquals(s1.get(1), sortYear.get(1));
        assertEquals(s1.get(2), sortYear.get(2));
        
        assertEquals(s1.toString(), sortYear.toString());
    }


    /**
     * tests to string
     */
    public void testToString() {
        s1.add(mc1);
        String str = s1.toString();
        String test = "Song Title: A\n" + "Song Artist: Matt\n"
            + "Song Genre: Pop\n" + "Song Year: 2010\n" + "Heard\n"
            + "reading:0 art:0 sports:0 music:0\n" + "Likes\n"
            + "reading:0 art:0 sports:0 music:0\n\n";

        assertEquals(str, test);
    }

}

/**
 * 
 */
package prj5;

/**
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/9/2018
 *
 */
public class People {
    private String major;
    private String hobby;
    private String region;


    /**
     * People constructor
     * 
     * @param major
     *            is major of person
     * @param hobby
     *            is preferred hobby of person
     * @param region
     *            is region person is from
     */
    public People(String major, String hobby, String region) {
        this.major = major;
        this.hobby = hobby;
        this.region = region;
    }


    /**
     * 
     * @return major
     */
    public String getMajor() {
        return major;
    }


    /**
     * 
     * @return hobby
     */
    public String getHobby() {
        return hobby;
    }


    /**
     * 
     * @return region
     */
    public String getRegion() {
        return region;
    }

}

package prj5;

/**
 * 
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/12/2018
 *
 */
public class MusicCollection {
    private String title;
    private String artist;
    private String year;
    private String genre;
    private int[] majorData = { 0, 0, 0, 0 };
    private int[] majorLikes = { 0, 0, 0, 0 };
    private int[] hobbyData = { 0, 0, 0, 0 };
    private int[] hobbyLikes = { 0, 0, 0, 0 };
    private int[] regionData = { 0, 0, 0, 0 };
    private int[] regionLikes = { 0, 0, 0, 0 };


    /**
     * Music Data collection constructor
     * 
     * @param title
     *            of song
     * @param artist
     *            of song
     * @param year
     *            song was released
     * @param genre
     *            of song
     */
    public MusicCollection(
        String title,
        String artist,
        String year,
        String genre) {
        this.title = title;
        this.artist = artist;
        this.year = year;
        this.genre = genre;
    }


    /**
     * 
     * @return title of song
     */
    public String getTitle() {
        return title;
    }


    /**
     * 
     * @return Artist of the song
     */
    public String getArtist() {
        return artist;
    }


    /**
     * 
     * @return year song was released
     */
    public String getYear() {
        return year;
    }


    /**
     * 
     * @return genre of the song
     */
    public String getGenre() {
        return genre;
    }


    /**
     * Adds "heard" to one of four spots based on which
     * major the listener is
     * 
     * @param i
     *            represents the index within the array
     * 
     */
    public void addMajorData(int i) {
        majorData[i]++;
    }


    /**
     * Adds a like to one of four spots based on which
     * major the listener is
     * 
     * @param i
     *            represents the index within the array
     * 
     */
    public void addMajorLikes(int i) {
        majorLikes[i]++;
    }


    /**
     * Adds "heard" to one of four spots based on which
     * hobby the listener prefers
     * 
     * @param i
     *            represents the index within the array
     * 
     */
    public void addHobbyData(int i) {
        hobbyData[i]++;
    }


    /**
     * Adds a like to one of four spots based on which
     * hobby the listener enjoys
     * 
     * @param i
     *            represents the index within the array
     * 
     */
    public void addHobbyLikes(int i) {
        hobbyLikes[i]++;
    }


    /**
     * Adds "heard" to one of four spots based on which
     * region the listener is from
     * 
     * @param i
     *            represents the index within the array
     * 
     */
    public void addRegionData(int i) {
        regionData[i]++;
    }


    /**
     * Adds a like to one of four spots based on which
     * region the listener is from
     * 
     * @param i
     *            represents the index within the array
     * 
     */
    public void addRegionLikes(int i) {
        regionLikes[i]++;
    }


    /**
     * @param index
     *            is index of major data array
     * @return An array of how many people heard a song
     *         based on which of the four majors they are
     */
    public int getMajorData(int index) {
        return majorData[index];
    }


    /**
     * @param index
     *            is index of hobby data array
     * @return An array of how many people heard a song
     *         based on which of the four hobbies they enjoy
     */
    public int getHobbyData(int index) {
        return hobbyData[index];
    }


    /**
     * @param index
     *            is index of region data array
     * @return An array of how many people heard a song
     *         based on which of the four regions they are from
     */
    public int getRegionData(int index) {
        return regionData[index];
    }


    /**
     * Sets indexes to be percentages
     * 
     * @param index
     *            is index of hobby array
     * @param count
     *            is song count
     */
    public void setHobbyData(int index, int count) {
        hobbyData[index] = ((100 * (hobbyData[index]) / count));
    }


    /**
     * @param index
     *            is index of major likes array
     * @return An array of how many people liked a song
     *         based on which of the four majors they are
     */
    public int getMajorLikes(int index) {
        return majorLikes[index];
    }


    /**
     * @param index
     *            is index of hobby likes array
     * @return An array of how many people liked a song
     *         based on which of the four hobbies they enjoy
     */
    public int getHobbyLikes(int index) {
        return hobbyLikes[index];
    }


    /**
     * @param index
     *            is index of region likes array
     * @return An array of how many people liked a song
     *         based on which of the four regions they are from
     */
    public int getRegionLikes(int index) {
        return regionLikes[index];
    }


    /**
     * Sets indexes to be percentages
     * 
     * @param index
     *            is index of hobby likes array
     * @param count
     *            is song count
     */
    public void setHobbyLikes(int index, int count) {
        hobbyLikes[index] = ((100 * (hobbyLikes[index]) / count));
    }


    /**
     * to String method
     * 
     * @return a string of a music collection
     */
    public String toString() {
        StringBuilder sB = new StringBuilder();
        sB.append("Title: " + getTitle() + "\n");
        sB.append("Artist: " + getArtist() + "\n");
        sB.append("Year: " + getYear() + "\n");
        sB.append("Genre: " + getGenre());

        return sB.toString();
    }

}

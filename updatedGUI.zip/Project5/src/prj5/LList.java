/**
 * 
 */
package prj5;

/**
 * @author Matt Robinson
 * @version 11/9/2018
 * 
 * Linked List class (some code from
 * Lab 10)
 *
 */
public class LList<T> {
    private Node<T> head;
    private int size;


    /**
     * Linked list constructor
     */
    public LList() {
        head = null;
        size = 0;
    }


    /**
     * 
     * @return size of list
     */
    public int size() {
        return size;
    }


    /**
     * Adds entry to list
     * 
     * @param entry
     *            is data added
     */
    public void add(T entry) {
        Node<T> curr = head;
        if (isEmpty()) {
            head = new Node<T>(entry);
        }
        else {
            for (int i = 0; i < size - 1; i++) {
                curr = curr.next;
            }

            Node<T> nNode = new Node<T>(entry);
            curr.setNextNode(nNode);
        }

        size++;
    }


    /**
     * Adds entry to list at specified index
     * 
     * @param index
     *            is position in list
     * @param entry
     *            is data added
     */
    public void add(int index, T entry) {
        Node<T> curr = head;
        if (isEmpty()) {
            head = new Node<T>(entry);
        }
        else {
            int i = 1;
            while (curr != null) {
                if (index == i) {
                    Node<T> newNode = new Node<T>(entry);
                    Node<T> nNode = curr.next;

                    curr.setNextNode(newNode);
                    newNode.setNextNode(nNode);
                }
                i++;
                curr = curr.getNextNode();
            }
        }

        size++;
    }


    /**
     * 
     * @return true if list is empty
     */
    public boolean isEmpty() {
        return size == 0;
    }


    /**
     * 
     * @param entry
     *            is data removed from list
     * @return true if entry is removed
     */
    public boolean remove(T entry) {
        Node<T> curr = head;
        if ((entry.equals(curr.data) && (head != null))) {
            head = head.next;
            size--;
            return true;

        }
        Node<T> n = null;
        while (curr.next != null) {
            if (curr.next.data.equals(entry)) {
                if (curr.next.next != null) {
                    curr.setNextNode(curr.next.next);
                }
                else {
                    curr.setNextNode(n);
                }
                size--;
                return true;
            }

            curr = curr.next;
        }

        return false;
    }


    /**
     * 
     * @param index
     *            is place of data being removed
     * @return true if entry is removed
     */
    public boolean remove(int index) {
        if (index < 0 || head == null) {
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }
        else {
            Node<T> curr = head;
            int currentIndex = 0;

            if ((index == 0)) {
                head = head.next;
                size--;
                return true;
            }

            while (curr.next != null) {
                if ((currentIndex + 1) == index) {
                    Node<T> newNext = curr.next.next;
                    curr.setNextNode(newNext);
                    size--;
                    return true;
                }
                curr = curr.next;
                currentIndex++;

            }
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }

    }


    /**
     * 
     * @param index
     *            is the place
     *            being searched for
     * @return true if method finds data
     */
    public T get(int index) {
        Node<T> curr = head;

        int currentIndex = 0;
        T data = null;
        while (curr != null) {
            if (currentIndex == index) {
                data = curr.data;
            }
            currentIndex++;
            curr = curr.next;
        }

        if (data == null) {
            throw new IndexOutOfBoundsException("Index exceeds the size.");
        }
        return data;

    }


    /**
     * Clears the linked list
     */
    public void clear() {
        if (head != null) {
            head.setNextNode(null);
            head = null;
        }
        size = 0;
    }


    /**
     * 
     * @param entry
     *            is data being searched for
     * @return true if list contains entry
     */
    public boolean contains(T entry) {
        Node<T> curr = head;
        while (curr != null) {
            if (entry.equals(curr.data)) {
                return true;
            }
            curr = curr.next;
        }
        return false;
    }


    /**
     * 
     * @param entry
     *            is data being searched for
     * @return last index
     */
    public int lastIndexOf(T entry) {
        int lastIndex = -1;
        Node<T> current = head;
        int currentIndex = 0;
        while (current != null) {
            if (entry.equals(current.data)) {
                lastIndex = currentIndex;
            }
            currentIndex++;
            current = current.next;
        }
        
        return lastIndex;
    }


    /**
     * To string method
     */
    public String toString() {
        String result = "{";
        Node<T> current = head;
        while (current != null) {
            result += "" + current.data;
            current = current.next;
            if (current != null) {
                result += ", ";
            }
        }
        result += "}";
        return result;

    }


    /**
     * Private Node class
     * 
     * @author Matt Robinson
     *
     * @param <T>
     *            represents a generic
     */
    private static class Node<T> {
        private T data;
        private Node<T> next;


        /**
         * Node constructor
         * 
         * @param data
         *            in a node
         */
        public Node(T data) {
            this.data = data;
        }


        /**
         * 
         * @return next Node in list
         */
        public Node<T> getNextNode() {
            return next;
        }


        public void setNextNode(Node<T> nNode) {
            this.next = nNode;
        }

    }

}

/**
 * 
 */
package prj5;

/**
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/12/2018
 *
 */
public class Sorter extends LList<MusicCollection> {

    /**
     * Sorts through songs and sorts them by genre
     */
    public void sortByGenre() {

        for (int i = 0; i < this.size() - 1; i++) {

            String curr = get(i + 1).getGenre().toLowerCase();
            MusicCollection song = get(i + 1);

            while ((i > -1) && (get(i).getGenre().toLowerCase().compareTo(
                curr) > 0)) {

                setPosition(i + 1, get(i));
                i--;
            }
            setPosition(i + 1, song);
        }

    }


    /**
     * Sorts songs by title
     */
    public void sortByTitle() {

        for (int i = 0; i < this.size() - 1; i++) {

            String curr = get(i + 1).getTitle();
            MusicCollection song = get(i + 1);

            while ((i > -1) && (get(i).getTitle().compareTo(curr) > 0)) {

                setPosition(i + 1, get(i));
                i--;
            }
            setPosition(i + 1, song);
        }

    }
    
    /**
     * sort songs by artist
     */
    public void sortByArtist()
    {
        for (int i = 0; i < this.size() - 1; i++) {

            String curr = get(i + 1).getArtist();
            MusicCollection song = get(i + 1);

            while ((i > -1) && (get(i).getArtist().compareTo(curr) > 0)) {

                setPosition(i + 1, get(i));
                i--;
            }
            setPosition(i + 1, song);
        }
    }
    
    /**
     * sort songs by release data
     */
    public void sortByYear()
    {
        for (int i = 0; i < this.size() - 1; i++) {

            String curr = get(i + 1).getYear();
            MusicCollection song = get(i + 1);

            while ((i > -1) && (get(i).getYear().compareTo(curr) > 0)) {

                setPosition(i + 1, get(i));
                i--;
            }
            setPosition(i + 1, song);
        }
    }


    /**
     * to string method
     * @return string of the sorter
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < size(); i++) {

            builder.append("Song Title: " + get(i).getTitle());
            builder.append("\nSong Artist: " + get(i).getArtist());
            builder.append("\nSong Genre: " + get(i).getGenre());
            builder.append("\nSong Year: " + get(i).getYear());

            builder.append("\nHeard");
            builder.append("\nreading:" + get(i).getHobbyData(0) + " art:"
                + get(i).getHobbyData(1) + " sports:" + get(i).getHobbyData(2)
                + " music:" + get(i).getHobbyData(3));
            builder.append("\nLikes");
            builder.append("\nreading:" + get(i).getHobbyLikes(0) + " art:"
                + get(i).getHobbyLikes(1) + " sports:" + get(i).getHobbyLikes(2)
                + " music:" + get(i).getHobbyLikes(3));
            builder.append("\n");
            builder.append("\n");
        }
        return builder.toString();
    }

}

package prj5;

import java.io.FileNotFoundException;

/**
 * 
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/12/2018
 * 
 *
 */
public class ProjectRunner {
    /**
     * Main method
     * 
     * @param arg
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        if (args.length == 2) {
            new Input(args[0], args[1]);
        }
        else {
            new Input("MusicSurveyData2018.csv", "SongList2018.csv");
        }

    }

}

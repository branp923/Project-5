/**
 * 
 */
package prj5;
import student.TestCase;

/**
 * @author Matt Robinson
 * @version 11/9/2018
 *
 */
public class PeopleTest extends TestCase {
    private People p;
    
    /**
     * set up method
     */
    public void setUp()
    {
        p = new People("CS", "math", "North");
    }
    
    /**
     * tests getMajor()
     */
    public void testGetMajor()
    {
        assertEquals("CS", p.getMajor());
    }
    
    /**
     * tests getHobby()
     */
    public void testGetHobby()
    {
        assertEquals("math", p.getHobby());
    }
    
    /**
     * tests getMajor()
     */
    public void testGetRegion()
    {
        assertEquals("North", p.getRegion());
    }

}

/**
 * 
 */
package prj5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Matt Robinson
 * @version 11/9/2018
 *
 */
public class Input {

    public Input(String music, String songList) 
        throws FileNotFoundException {
        
        sortGenre(songList);
        sortTitle(songList);
    }
        


    /**
     * 
     * @param arg
     * @throws FileNotFoundException 
     */
    public static void main(String[] args) 
        throws FileNotFoundException {
        if (args.length == 2) {
            new Input(args[0], args[1]);
        }
        else {
            new Input("MusicSurveyDataTest1.csv", "SongListTest1.csv");
        }

    }

    /**
     * Read song data
     */
    public void readSongData(String filename)
    {
        
    }

    /**
     * Sort by genre
     * 
     * @param genre
     */
    public void sortGenre(String genre) {

    }


    /**
     * Sort by title
     * 
     * @param title
     */
    public void sortTitle(String title) {

    }
}

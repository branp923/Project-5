package prj5;

public class ProjectRunner {
    public static void main(String[] args) {
        MusicGUI musicGUI = new MusicGUI();
    }

}

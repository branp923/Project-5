/**
 * 
 */
package prj5;

/**
 * @author mattrobinson
 *
 */
public class Input {

}

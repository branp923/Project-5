package prj5;

public class Input {

    public Input() {
        // TODO Auto-generated constructor stub
    }

}

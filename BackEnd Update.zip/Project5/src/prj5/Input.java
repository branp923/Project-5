/**
 * 
 */
package prj5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Matt Robinson
 * @author Brandon Pearl
 * @version Cole Amster
 * @version 11/9/2018
 *
 */
public class Input {
    private static Sorter songs;
    private static LList<People> peopleList;

    /**
     * Number of people in each major respectively
     */
    public static int[] majorList = { 0, 0, 0, 0 };
    /**
     * Number of people that are from each region respectively
     */
    public static int[] regionList = { 0, 0, 0, 0 };
    /**
     * Number of people that prefer each hobby respectively
     */
    public static int[] hobbyList = { 0, 0, 0, 0 };


    /**
     * Input Constructor
     * 
     * @param music
     *            represents music survey data being read in
     * @param songList
     *            represents song data being read in
     * @throws FileNotFoundException
     */
    public Input(String music, String songList) throws FileNotFoundException {

        songs = new Sorter();
        peopleList = new LList<People>();

        readSongData(songList);
        readPeopleData(music);
        
    }


    /**
     * Main method
     * 
     * @param arg
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        if (args.length == 2) {
            new Input(args[0], args[1]);
        }
        else {
            new Input("MusicSurveyData2018.csv", "SongList2018.csv");
        }

    }


    /**
     * Read song data
     * 
     * @throws FileNotFoundException
     */
    public void readSongData(String filename) throws FileNotFoundException {
        File nFile = new File(filename);
        Scanner scanner = new Scanner(nFile);

        scanner.nextLine();
        while (scanner.hasNextLine()) {
            String[] songData = scanner.nextLine().trim().split(",");
            songs.add(new MusicCollection(songData[0], songData[1], songData[2],
                songData[3]));
        }

        scanner.close();
    }


    /**
     * Read people data
     * 
     * @param filename
     * @throws FileNotFoundException
     */
    public void readPeopleData(String filename) throws FileNotFoundException {

        File file = new File(filename);
        Scanner scanner = new Scanner(file);
        scanner.nextLine();

        String[] str;
        while (scanner.hasNextLine()) {
            String[] collection = scanner.nextLine().trim().split(",");

            if (collection.length == (songs.size() * 2 + 4)) {

                str = new String[collection.length + 1];
                for (int i = 0; i < collection.length; i++) {
                    str[i] = collection[i];
                }

                str[collection.length] = null;
            }
            else {
                str = collection;
            }

            if (collection.length > 4) {

                String majorString = collection[2];
                if (majorString.equals("reading")) {
                    majorList[0]++;
                }
                else if (majorString.equals("art")) {
                    majorList[1]++;
                }
                else if (majorString.equals("sports")) {
                    majorList[2]++;
                }
                else {
                    majorList[3]++;
                }

                String regionString = collection[3];
                if (regionString.equals("reading")) {
                    regionList[0]++;
                }
                else if (regionString.equals("art")) {
                    regionList[1]++;
                }
                else if (regionString.equals("sports")) {
                    regionList[2]++;
                }
                else {
                    regionList[3]++;
                }

                String hobbyString = collection[4];

                if (hobbyString.equals("reading")) {
                    hobbyList[0]++;
                }
                else if (hobbyString.equals("art")) {
                    hobbyList[1]++;
                }
                else if (hobbyString.equals("sports")) {
                    hobbyList[2]++;
                }
                else {
                    hobbyList[3]++;

                }

                People person = new People(majorString, hobbyString,
                    regionString);
                peopleList.add(person);

                int index = 0;

                for (int i = 5; i < collection.length - 1; i += 2) {
                    if (collection[i].equals("Yes")) {

                        songs.get(index).addMajorData(findIndex(majorString,
                            "Math or CMDA", "Computer Science",
                            "Other Engineering"));
                        songs.get(index).addHobbyData(findIndex(hobbyString,
                            "reading", "art", "sports"));
                        songs.get(index).addHobbyData(findIndex(regionString,
                            "Northeast", "Southeast",
                            "United States (other than Southeast or Northwest)"));

                    }

                    if (collection[i + 1].equals("Yes")) {
                        
                        songs.get(index).addMajorLikes(findIndex(majorString,
                            "Math or CMDA", "Computer Science",
                            "Other Engineering"));
                        songs.get(index).addHobbyLikes(findIndex(hobbyString,
                            "reading", "art", "sports"));
                        songs.get(index).addHobbyLikes(findIndex(regionString,
                            "Northeast", "Southeast",
                            "United States (other than Southeast or Northwest)"));

                    }

                    index++;
                }
            }

        }

        scanner.close();
    }


    /**
     * Finds the index of where to add to in the major,
     * hobby and region arrays
     * 
     * @param i
     * @param zero
     * @param one
     * @param two
     * @return index of respective major, hobby, or region
     */
    private static int findIndex(
        String i,
        String zero,
        String one,
        String two) {
        if (i.equals(zero)) {
            return 0;
        }
        else if (i.equals(one)) {
            return 1;
        }
        else if (i.equals(two)) {
            return 2;
        }
        else {
            return 3;
        }

    }
}

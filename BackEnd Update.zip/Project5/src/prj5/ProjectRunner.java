package prj5;

/**
 * 
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/12/2018
 * 
 *
 */
public class ProjectRunner {
    /**
     * Main method
     * 
     * @param args
     *            - string argument
     */
    public static void main(String[] args) {
        GUIMusic musicGUI = new GUIMusic();
    }

}

/**
 * 
 */
package prj5;

import CS2114.Button;
import CS2114.Window;
import CS2114.WindowSide;
import CS2114.TextShape;
import java.awt.Color;
import CS2114.Shape;
import CS2114.SquareShape;
import java.awt.Graphics;


/**
 * 
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/12/2018
 *
 */
public class GUIMusic {
    
    private Button sortArtistNameButton;
    private Button sortSongTitleButton;
    private Button sortReleaseYearButton;
    private Button sortGenreButton;
    private Button prevButton;
    private Button nextButton;
    private Button representHobbyButton;
    private Button representMajorButton;
    private Button representRegionButton;
    private Button quitButton;
    private Window window;
    private Graphics graphics;
// private DataCollection dataCollection;
    
    /**
     * Constructor for GUIMusic
     */
    public GUIMusic() {

        // Create window and add buttons
        window = new Window("Project 5");
        window.setSize(600, 600);
        
        prevButton = new Button("< Prev");
        window.addButton(prevButton, WindowSide.NORTH);
        
        sortArtistNameButton = new Button("Sort by Artist Name");
        window.addButton(sortArtistNameButton, WindowSide.NORTH);
        
        sortSongTitleButton = new Button("Sort by Song Title");
        window.addButton(sortSongTitleButton, WindowSide.NORTH);
        
        sortReleaseYearButton = new Button("Sort by Release Year");
        window.addButton(sortReleaseYearButton, WindowSide.NORTH);
        
        sortGenreButton = new Button("Sort by Genre");
        window.addButton(sortGenreButton, WindowSide.NORTH);
        
        nextButton = new Button("Next >");
        window.addButton(nextButton, WindowSide.NORTH);
        
        representHobbyButton = new Button("Represent Hobby");
        window.addButton(representHobbyButton, WindowSide.SOUTH);
        
        representMajorButton = new Button("Represent Major");
        window.addButton(representMajorButton, WindowSide.SOUTH);
        
        representRegionButton = new Button("Represent Region");
        window.addButton(representRegionButton, WindowSide.SOUTH);
        
        quitButton = new Button("Quit");
        quitButton.onClick(this, "clickedQuit");
        window.addButton(quitButton, WindowSide.SOUTH);
        
        // Create border for legend and divider for heard and likes
        Shape legendBorder = new Shape(window.getGraphPanelWidth() - 130, window
            .getGraphPanelHeight() / 2 - 10, 120, window.getGraphPanelHeight()
                / 2);
        legendBorder.setForegroundColor(Color.BLACK);
        legendBorder.setBackgroundColor(Color.WHITE);
        
        Shape divider = new Shape(window.getGraphPanelWidth() - 70, window
            .getGraphPanelHeight() / 2 + 130, 5, 40);
        divider.setForegroundColor(Color.BLACK);
        divider.setBackgroundColor(Color.BLACK);
        
        // Fill Legend
        TextShape hobbyLegend = new TextShape(0, 0, "Hobby Legend",
            Color.BLACK);
        hobbyLegend.setX((window.getGraphPanelWidth()) - 120);
        hobbyLegend.setY((window.getGraphPanelHeight()) / 2);
        
        TextShape read = new TextShape(0, 0, "Read", Color.MAGENTA);
        read.setX((window.getGraphPanelWidth()) - 120);
        read.setY((window.getGraphPanelHeight()) / 2 + 20);
        read.setBackgroundColor(Color.WHITE);
        
        TextShape art = new TextShape(0, 0, "Art", Color.BLUE);
        art.setX((window.getGraphPanelWidth()) - 120);
        art.setY((window.getGraphPanelHeight()) / 2 + 40);
        art.setBackgroundColor(Color.WHITE);
        
        TextShape sports = new TextShape(0, 0, "Sports", Color.ORANGE);
        sports.setX((window.getGraphPanelWidth()) - 120);
        sports.setY((window.getGraphPanelHeight()) / 2 + 60);
        sports.setBackgroundColor(Color.WHITE);
        
        TextShape music = new TextShape(0, 0, "Music", Color.GREEN);
        music.setX((window.getGraphPanelWidth()) - 120);
        music.setY((window.getGraphPanelHeight()) / 2 + 80);
        music.setBackgroundColor(Color.WHITE);
        
        TextShape songTitle = new TextShape(0, 0, "Song Title", Color.BLACK);
        songTitle.setX((window.getGraphPanelWidth()) - 105);
        songTitle.setY((window.getGraphPanelHeight()) / 2 + 100);
        songTitle.setBackgroundColor(Color.WHITE);
        
        TextShape heard = new TextShape(0, 0, "Heard", Color.BLACK);
        heard.setX((window.getGraphPanelWidth()) - 120);
        heard.setY((window.getGraphPanelHeight()) / 2 + 140);
        heard.setBackgroundColor(Color.WHITE);
        
        TextShape likes = new TextShape(0, 0, "Likes", Color.BLACK);
        likes.setX((window.getGraphPanelWidth()) - 60);
        likes.setY((window.getGraphPanelHeight()) / 2 + 140);
        likes.setBackgroundColor(Color.WHITE);
        
        // Add legend contents and border to window
        window.addShape(hobbyLegend);
        window.addShape(read);
        window.addShape(art);
        window.addShape(sports);
        window.addShape(music);
        window.addShape(songTitle);
        window.addShape(heard);
        window.addShape(likes);
        window.addShape(divider);
        window.addShape(legendBorder);

    }


    /**
     * Sorts by artist.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedSortArtist(Button button) {
        // implement later
    }


    /**
     * Sorts by song title.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedSortSongTitle(Button button) {
        // implement later
    }


    /**
     * Sorts by release year.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedSortReleaseYear(Button button) {
        // implement later
    }


    /**
     * Sorts by genre.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedSortGenre(Button button) {
        // implement later
    }


    /**
     * Navigates to previous data.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedPrev(Button button) {

    }


    /**
     * Navigates to next data.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedNext(Button button) {

    }


    /**
     * Represents data by hobby.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedRepresentHobby(Button button) {

    }


    /**
     * Represents data by major.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedRepresentMajor(Button button) {

    }


    /**
     * Represents data by region.
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedRepresentRegion(Button button) {

    }


    /**
     * Quits program
     * 
     * @param button
     *            Button that was clicked
     */
    public void clickedQuit(Button button) {
        System.exit(0);
    }

}

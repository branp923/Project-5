/**
 * 
 */
package prj5;

import student.TestCase;

/**
 * @author Matt Robinson
 * @author Brandon Pearl
 * @author Cole Amster
 * @version 11/9/2018
 *
 */
public class LListTest extends TestCase {
    private LList<String> s1;
    private LList<String> s2;
    private LList<String> s3;


    /**
     * Set up method
     */
    public void setUp() {
        s1 = new LList<String>();
        s2 = new LList<String>();
        s3 = new LList<String>();

        s1.add("1");
        s1.add("2");
    }


    /**
     * tests Size()
     */
    public void testSize() {
        assertEquals(2, s1.size());

    }


    /**
     * tests Add()
     */
    public void testAdd() {
        s2.add(0, "1");
        assertEquals(1, s2.size());

        s1.add(0, "1");
        assertEquals(3, s1.size());

        s1.add(2, "2");
        assertEquals(4, s1.size());

        s3.add("1");
        assertEquals(1, s3.size());

        s2.add("1");
        assertEquals(2, s2.size());

    }


    /**
     * tests isEmpty()
     */
    public void testIsEmpty() {
        assertFalse(s1.isEmpty());
        assertTrue(s2.isEmpty());
    }


    /**
     * tests remove(T) on non-null head
     */
    public void testRemove() {
        assertEquals("1", s1.get(0));
        assertNotNull((s1.get(0)));
        assertTrue(s1.remove("1"));
        assertEquals(1, s1.size());

    }
    /**
     * tests remove(T) when entry is not the head and is found
     */
    public void testRemove1() {
        assertTrue(s1.remove("2"));
        assertEquals(1, s1.size());

    }
    /**
     * tests remove(T) when entry is not found
     */
    public void testRemove2() {
        assertFalse(s1.remove("5"));
        assertEquals(2, s1.size());
    }
    /**
     * tests remove(int) when head == null
     */
    public void testRemove11() {
        Exception exc = null;
        try {
            s2.remove(0);
            fail("remove(0) doesn't throw exception");
        }
        catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
        assertTrue("remove(0) throws wrong exception",
            exc instanceof IndexOutOfBoundsException);
        
        exc = null;

    }


    /**
     * tests remove(int) when index < 0
     */
    public void testRemove12() {
        Exception exc = null;
        try {
            s1.remove(-1);
            fail("remove(-1) doesn't throw exception");
        }
        catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
        assertTrue("remove(-1) throws wrong exception",
            exc instanceof IndexOutOfBoundsException);
        
        exc = null;
    }
    /**
     * tests remove(int) when index > the length of the list
     */
    public void testRemove13() {
        Exception exc = null;
        try {
            s1.remove(2);
            fail("remove(2) doesn't throw exception");
        }
        catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
        assertTrue("remove(2) throws wrong exception",
            exc instanceof IndexOutOfBoundsException);
        
        exc = null;
    }
    /**
     * tests remove(int) when index is valid
     */
    public void testRemove14() {
        assertTrue(s1.remove(1));
        assertEquals(1, s1.size());

        assertTrue(s1.remove(0));
        assertEquals(0, s1.size());
    }


    /**
     * tests get()
     */
    public void testGet() {
        assertEquals("1", s1.get(0));
    }


    /**
     * tests get() exceptions
     */
    public void testGet2() {
        Exception exc = null;
        try {
            s1.get(-1);
            fail("get() doesn't throw exception");
        }
        catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
        assertTrue("get() throws wrong exception",
            exc instanceof IndexOutOfBoundsException);
    }
    
    /**
     * test set position method
     */
    public void testGetPosition()
    {
        s1.add("3");
        s1.add("4");
        s1.add("5");
        
        assertEquals(5, s1.size());
        
        s1.setPosition(0, "5");
        assertEquals(5, s1.size());
        assertEquals("5", s1.get(0));
        
    }
    
    /**
     * tests clear()
     */
    public void testClear()
    {
        s1.clear();
        assertEquals(0, s1.size());
        
        s2.clear();
        assertEquals(0, s2.size());
    }
    
    /**
     * tests contains()
     */
    public void testContains()
    {
        assertTrue(s1.contains("2"));
        assertFalse(s1.contains("10"));
    }
    
    /**
     * tests lastIndexOf()
     */
    public void testLastIndexOf()
    {
        assertEquals(0, s1.lastIndexOf("1"));
        assertEquals(-1, s1.lastIndexOf("10"));
    }
    
    /**
     * tests toString()
     */
    public void testToString()
    {
        assertEquals("{}", s2.toString());
        assertEquals("{1, 2}", s1.toString());
    }

}
